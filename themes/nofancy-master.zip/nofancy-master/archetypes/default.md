+++
title = "{{ replace .TranslationBaseName "-" " " | title }}"
date = "{{ .Date }}"
categories = ["misc"]
draft = "true"
+++
